let xb = 350;
let yb = 200;
let diametro = 70;
let vxb = 5;
let vyb = 5;

function setup() {
    createCanvas(500, 400);
}
function draw() {
  background(0);
  circle(xb,yb,diametro);
  xb += vxb;
  yb += vyb;
  if(xb > width || xb < 0){
    vxb *= -1;
  }
  if(yb > height || yb < 0){
    vyb *= -1;
  }
}